#!/bin/sh
echo "file: $1" > exec.out
