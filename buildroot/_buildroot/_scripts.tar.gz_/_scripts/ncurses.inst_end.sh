ln -sf libformw.so.6.0 $DESTROOT/usr/lib/libform.so
ln -sf libmenuw.so.6.0 $DESTROOT/usr/lib/libmenu.so
ln -sf libncursesw.so.6.0 $DESTROOT/usr/lib/libncurses.so
ln -sf libpanelw.so.6.0 $DESTROOT/usr/lib/libpanel.so

mkdir $DESTROOT/usr/include/ncursesw
mkdir $DESTROOT/usr/include/ncurses

(cd $DESTROOT/usr/include
for i in *.h; do
    ln -s ../$i $DESTROOT/usr/include/ncursesw/$i
    ln -s ../$i $DESTROOT/usr/include/ncurses/$i
done)
