rm $DESTROOT/usr/share/fonts/X11/misc/fonts.dir
