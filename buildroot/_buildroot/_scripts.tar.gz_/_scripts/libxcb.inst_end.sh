find $DESTROOT/usr/share/doc \( -type d -a \( ! -group root -o ! -user root \) \) | \
while read file; do
    chown 0:0 "$file"
done
rm -rf $DESTROOT/var/run 2> /dev/null
