SONAMES=('libpam' 'libpam_misc' 'libpamc')
mkdir -p $DESTROOT/usr/lib

for lib in ${SONAMES[@]}; do
    #mv $DESTROOT/lib/${lib}.{so,la,a} $DESTROOT/usr/lib
    mv $DESTROOT/lib/${lib}.so $DESTROOT/usr/lib
    mv $DESTROOT/lib/${lib}.la $DESTROOT/usr/lib
    mv $DESTROOT/lib/${lib}.a $DESTROOT/usr/lib
done

for lib in ${SONAMES[@]}; do
    LNK=$(readlink $DESTROOT/usr/lib/${lib}.so)
    #basename
    ln -sfv ../../lib/$LNK $DESTROOT/usr/lib/${lib}.so
done

#mv $DESTROOT/lib/libpam.{so,la,a} $DESTROOT/usr/lib
#mv $DESTROOT/lib/libpam_misc.{so,la,a} $DESTROOT/usr/lib
#mv $DESTROOT/lib/libpamc.{so,la,a} $DESTROOT/usr/lib

#LNK=$(readlink $DESTROOT/usr/lib/libpam.so)
#basename
#ln -sfv ../../lib/$LNK $DESTROOT/usr/lib/libpam.so

#LNK=$(readlink $DESTROOT/usr/lib/libpam_misc.so)
#basename
#ln -sfv ../../lib/$LNK $DESTROOT/usr/lib/libpam_misc.so

#LNK=$(readlink $DESTROOT/usr/lib/libpamc.so)
#basename
#ln -sfv ../../lib/$LNK $DESTROOT/usr/lib/libpamc.so
rm -rf $DESTROOT/var/run 2> /dev/null
