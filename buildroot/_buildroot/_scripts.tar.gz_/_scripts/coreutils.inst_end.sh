mkdir -p $DESTROOT/usr/bin
ln -sf ../../bin/env $DESTROOT/usr/bin/env
ln -sf ../../bin/install $DESTROOT/usr/bin/install

mkdir -p $DESTROOT/usr/lib/alt-bin/coreutils/man
mv $DESTROOT/bin/kill $DESTROOT/usr/lib/alt-bin/coreutils
mv $DESTROOT/usr/share/man/man1/kill.1 $DESTROOT/usr/lib/alt-bin/coreutils/man
