rm $DESTROOT/bin/uptime
rm $DESTROOT/usr/share/man/man1/uptime.1
mkdir -p $DESTROOT/usr/lib/alt-bin/procps-ng/man
mv $DESTROOT/bin/kill $DESTROOT/usr/lib/alt-bin/procps-ng
mv $DESTROOT/usr/share/man/man1/kill.1 $DESTROOT/usr/lib/alt-bin/procps-ng/man
