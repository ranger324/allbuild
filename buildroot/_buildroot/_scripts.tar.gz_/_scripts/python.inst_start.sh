mkdir -p $DESTROOT/usr/lib/python2.7/lib2to3
cat $SOURCE_DIR/Lib/lib2to3/Grammar.txt > $DESTROOT/usr/lib/python2.7/lib2to3/Grammar.txt
cat $SOURCE_DIR/Lib/lib2to3/PatternGrammar.txt > $DESTROOT/usr/lib/python2.7/lib2to3/PatternGrammar.txt
