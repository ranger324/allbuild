rm $DESTROOT/etc/ethertypes
rmdir $DESTROOT/etc
