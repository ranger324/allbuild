rm -rf $DESTROOT/usr/libexec 2> /dev/null
rm $DESTROOT/usr/share/man/man8/rmt.8
