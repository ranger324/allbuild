rm $DESTROOT/sbin/fsck
rm $DESTROOT/usr/share/man/man8/fsck.8
mv $DESTROOT/usr/bin/reset $DESTROOT/usr/bin/reset-ul
