rm -rf $DESTROOT/var/run 2> /dev/null

########rm init.d
rm -rf $DESTROOT/etc/init.d
rm -rf $DESTROOT/etc/rc?.d
########
