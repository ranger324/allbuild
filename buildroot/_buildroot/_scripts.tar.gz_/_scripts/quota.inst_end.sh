rm $DESTROOT/usr/include/rpcsvc/rquota.h
rm $DESTROOT/usr/include/rpcsvc/rquota.x
rmdir $DESTROOT/usr/include/rpcsvc
rmdir $DESTROOT/usr/include
