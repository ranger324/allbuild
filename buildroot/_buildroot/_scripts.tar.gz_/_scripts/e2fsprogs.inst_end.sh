gunzip $DESTROOT/usr/share/info/libext2fs.info.gz
rm -rf $DESTROOT/var/run 2> /dev/null
