manpages=('cgdisk.8' 'gdisk.8' 'sgdisk.8')
mkdir -p $DESTROOT/usr/share/man/man8
for i in ${manpages[@]}; do
    cp $SOURCE_DIR/$i $DESTROOT/usr/share/man/man8
done
