pkgdir=/dest
MKOPTS="-j 3"
CFLAGS="$CFLAGS -Wno-error=cpp" ./configure --sbindir=/sbin --prefix=/usr --sysconfdir=/etc --libdir=/lib \
    --disable-grub-mkfont --disable-nls --disable-grub-mount
# --disable-device-mapper
# --disable-grub-mount
make $MKOPTS || return 1
make DESTDIR=$pkgdir install

mv $pkgdir/etc/bash_completion.d/grub $pkgdir/etc/bash_completion.d/grub.sh
mkdir -p $pkgdir/boot/grub/i386-pc
mkdir -p $pkgdir/boot/grub/fonts
mkdir -p $pkgdir/boot/grub/locale
cp -dp $pkgdir/lib/grub/i386-pc/*.{lst,mod,o} $pkgdir/boot/grub/i386-pc
cp -dp $pkgdir/lib/grub/i386-pc/boot.img $pkgdir/boot/grub/i386-pc
cp -dp $pkgdir/lib/grub/i386-pc/modinfo.sh $pkgdir/boot/grub/i386-pc

#core.img
./grub-mkimage -p /boot/grub -O i386-pc -o grubcore.img -d ./grub-core biosdisk ext2 fat part_gpt part_msdos
cp -dp grubcore.img $pkgdir/boot/grub/i386-pc/core.img

#cp $startdir/grub-mkconfig_lib $pkgdir/lib/grub
#cp $startdir/ascii.pf2 $startdir/unicode.pf2 $pkgdir/usr/share/grub
#rm -rf $pkgdir/usr/share/man
