/tools/bin/gcc -dumpspecs | sed 's%32:../lib%32:../../tools/lib%'
