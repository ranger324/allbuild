mkdir -p $DESTROOT/usr/lib/pkgconfig
cat > $DESTROOT/usr/lib/pkgconfig/readline.pc << EOF
prefix=/usr
exec_prefix=/usr
libdir=\${exec_prefix}/lib
includedir=\${prefix}/include

Name: Readline
Description: Gnu Readline library for command line editing
URL: http://tiswww.cwru.edu/php/chet/readline/rltop.html
Version: 7.0
Requires.private: tinfo
Libs: -L\${libdir} -lreadline
Cflags: -I\${includedir}/readline
EOF
