mv $DESTROOT/etc/bash_completion.d/grub $DESTROOT/etc/bash_completion.d/grub.sh

mkdir -p $DESTROOT/boot/grub/i386-pc
mkdir -p $DESTROOT/boot/grub/fonts
mkdir -p $DESTROOT/boot/grub/locale
cp -dp $DESTROOT/lib/grub/i386-pc/*.{lst,mod,o} $DESTROOT/boot/grub/i386-pc
cp -dp $DESTROOT/lib/grub/i386-pc/boot.img $DESTROOT/boot/grub/i386-pc
cp -dp $DESTROOT/lib/grub/i386-pc/modinfo.sh $DESTROOT/boot/grub/i386-pc

#core.img
$SOURCE_DIR/grub-mkimage -p /boot/grub -O i386-pc -o $SOURCE_DIR/grubcore.img -d $SOURCE_DIR/grub-core biosdisk ext2 fat part_gpt part_msdos
cp -dp $SOURCE_DIR/grubcore.img $DESTROOT/boot/grub/i386-pc/core.img
