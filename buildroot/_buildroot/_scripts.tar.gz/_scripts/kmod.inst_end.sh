mkdir -p $DESTROOT/etc/modprobe.d

mkdir -p $DESTROOT/bin
mv $DESTROOT/usr/bin/kmod $DESTROOT/bin
rmdir $DESTROOT/usr/bin

#for i in depmod insmod lsmod modinfo modprobe rmmod; do
#    rm -f $DESTROOT/sbin/$i
#done

mkdir -p $DESTROOT/sbin
for i in depmod insmod lsmod modinfo modprobe rmmod; do
    ln -sf ../bin/kmod $DESTROOT/sbin/$i
done
