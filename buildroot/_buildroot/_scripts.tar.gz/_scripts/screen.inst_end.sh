mkdir -p $DESTROOT/etc
cp $SOURCE_DIR/etc/screenrc $DESTROOT/etc
