rm -rf $DESTROOT/etc/init.d
