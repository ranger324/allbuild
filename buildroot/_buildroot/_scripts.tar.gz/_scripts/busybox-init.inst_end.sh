B_BOX_BIN=busybox-init

rm $DESTROOT/linuxrc

mkdir -p $DESTROOT/bin/alt-bin
mv $DESTROOT/bin/busybox $DESTROOT/bin/alt-bin/$B_BOX_BIN

rm $DESTROOT/sbin/halt
rm $DESTROOT/sbin/init
rm $DESTROOT/sbin/poweroff
rm $DESTROOT/sbin/reboot
cp -dp $DESTROOT/bin/alt-bin/$B_BOX_BIN $DESTROOT/sbin/halt
cp -dp $DESTROOT/bin/alt-bin/$B_BOX_BIN $DESTROOT/sbin/init
cp -dp $DESTROOT/bin/alt-bin/$B_BOX_BIN $DESTROOT/sbin/poweroff
cp -dp $DESTROOT/bin/alt-bin/$B_BOX_BIN $DESTROOT/sbin/reboot

rm $DESTROOT/usr/sbin/killall5
rmdir $DESTROOT/usr/sbin $DESTROOT/usr
cp -dp $DESTROOT/bin/alt-bin/$B_BOX_BIN $DESTROOT/sbin/killall5
