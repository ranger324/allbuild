mkdir -p $DESTROOT/usr/share/aclocal
cat _scripts/files/$PKG/gtk-doc.m4 > $DESTROOT/usr/share/aclocal/gtk-doc.m4
