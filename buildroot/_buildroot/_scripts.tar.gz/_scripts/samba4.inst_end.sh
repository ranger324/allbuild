rm -rf $DESTROOT/var/run 2> /dev/null
mkdir -p $DESTROOT/var/smb
