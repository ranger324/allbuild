rm $DESTROOT/etc/ld.so.cache
rm -rf $DESTROOT/var/run 2> /dev/null
