rm $DESTROOT/etc/ld.so.cache
