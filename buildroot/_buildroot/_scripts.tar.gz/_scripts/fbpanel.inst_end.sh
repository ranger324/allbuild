mkdir -p $DESTROOT/var/run/fbpanel
chmod 1777 $DESTROOT/var/run/fbpanel
