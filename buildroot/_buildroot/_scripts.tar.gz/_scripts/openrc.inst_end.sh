chmod 755 $DESTROOT/lib/lib*.so*
