ln -sf ../bin/cpp $DESTROOT/usr/lib/cpp
ln -sf ../usr/bin/cpp $DESTROOT/lib/cpp
ln -sf gcc $DESTROOT/usr/bin/cc
