ln -sfv cpp $DESTROOT/usr/bin/x86_64-pc-linux-gnu-cpp
ln -sfv ../bin/cpp $DESTROOT/usr/lib/cpp
