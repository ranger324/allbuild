mkdir -p $DESTROOT/usr/bin
ln -sf ../../bin/env $DESTROOT/usr/bin/env
ln -sf ../../bin/install $DESTROOT/usr/bin/install
