chmod 755 $DESTROOT/usr/lib/*.la
chmod 755 $DESTROOT/usr/lib/*.so*
