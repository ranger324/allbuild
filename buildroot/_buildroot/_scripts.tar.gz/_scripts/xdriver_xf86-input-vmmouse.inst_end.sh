rm -rf $DESTROOT/usr/share/hal
rm -rf $DESTROOT/usr/lib/hal
