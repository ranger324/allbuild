mv $DESTROOT/etc/init.d/S01logging $DESTROOT/etc/init.d/S01log-syslog-ng
