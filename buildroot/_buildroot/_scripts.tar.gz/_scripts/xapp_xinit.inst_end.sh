rm -rf $DESTROOT/etc/X11/xinit
