ln -sfv gawk $DESTROOT/usr/bin/awk
