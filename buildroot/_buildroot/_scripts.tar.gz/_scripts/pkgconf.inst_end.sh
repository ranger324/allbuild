ln -sf pkgconf $DESTROOT/usr/bin/pkg-config
