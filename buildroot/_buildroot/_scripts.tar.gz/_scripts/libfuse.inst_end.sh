rm -rf $DESTROOT/dev
rm -rf $DESTROOT/etc/init.d
