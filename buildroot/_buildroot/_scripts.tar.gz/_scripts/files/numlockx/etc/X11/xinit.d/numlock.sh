[ -x /usr/bin/numlockx ] && numlockx on
