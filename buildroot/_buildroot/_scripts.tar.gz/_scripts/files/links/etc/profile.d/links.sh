if [ ! -z "$DISPLAY" ]; then
    alias links='links -driver x'
else
    if [ -c /dev/fb0 ]; then
	alias links='links -driver fb'
    fi
fi
