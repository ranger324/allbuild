if [ -z "$DISPLAY" ]; then
    if [ "$(locale charmap)" = "UTF-8" ]; then
	alias pstree='pstree -phanU'
    else
	alias pstree='pstree -phanG'
    fi
else
    alias pstree='pstree.x11 -phan'
fi
