
[ -e /etc/default/xhost ] && source /etc/default/xhost

if [ "$X11ACCESSCONTROL" = "0" ]; then
    if [ -x /usr/bin/xhost ]; then
	xhost +
    fi
else
    if [ -x /usr/bin/xhost -a -x /bin/id ]; then
	xhost +si:localuser:`id -un` > /dev/null
    fi
fi
