#!/bin/sh

if [ $# != 1 ]; then
	exit 1
fi
set $*

case "$1" in
    button/power)
	case "$2" in
	    PWRF|PBTN)
		_reinit -p && poweroff
	    ;;
	    LNXPWRBN:00)
		_reinit -p && poweroff
	    ;;
	    *)
		logger "ACPI action button/power $2 is not defined"
	    ;;
	esac
    ;;
    *)
	logger "ACPI group $1 is not defined"
    ;;
esac
##reboot (reboot poweroff init 0 init 6)
#chvt 1
#sleep 0.5
#init 0
