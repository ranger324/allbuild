[ -f /etc/default/locale ]  && . /etc/default/locale
[ ! -z "$LANG" ] && export LANG
