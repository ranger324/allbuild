
ls /etc/X11/xresources.d/* > /dev/null 2>&1
retval=$?
if [ "$retval" = 0 ]; then
    for i in /etc/X11/xresources.d/*; do
	xrdb -merge $i
    done
fi

ls $HOME/.xresources.d/* > /dev/null 2>&1
retval=$?
if [ "$retval" = 0 ]; then
    for i in $HOME/.xresources.d/*; do
	xrdb -merge $i
    done
fi
