
[ -e /etc/default/xkeyboard ] && source /etc/default/xkeyboard

if [ -x /usr/bin/xset -a ! -z "$XKB_DELAY" -a ! -z "$XKB_RATE" ]; then
    xset r rate $XKB_DELAY $XKB_RATE
fi
