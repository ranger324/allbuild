
ls /etc/X11/xmodmap.d/* > /dev/null 2>&1
retval=$?
if [ "$retval" = 0 ]; then
    for i in /etc/X11/xmodmap.d/*; do
	xmodmap $i
    done
fi

ls $HOME/.xmodmap.d/* > /dev/null 2>&1
retval=$?
if [ "$retval" = 0 ]; then
    for i in $HOME/.xmodmap.d/*; do
	xmodmap $i
    done
fi
