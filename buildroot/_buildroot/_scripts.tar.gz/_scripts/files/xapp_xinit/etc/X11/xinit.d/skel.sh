(cd /etc/skel; find -type f | cpio -p --make-directories ~ 2> /dev/null)
