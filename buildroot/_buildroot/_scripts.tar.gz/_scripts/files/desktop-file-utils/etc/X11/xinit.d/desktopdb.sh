if [ ! -d ~/.local/share/applications ]; then
    mkdir -p ~/.local/share/applications
    chmod 2700 ~/.local ~/.local/share ~/.local/share/applications
fi
update-desktop-database ~/.local/share/applications
