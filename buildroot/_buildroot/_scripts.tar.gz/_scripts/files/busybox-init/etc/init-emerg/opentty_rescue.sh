
sleep 30

if [ -z "$(hostname)" ]; then
    HOSTNAME="localhost"
    [ -e /etc/conf.d/hostname ] && . /etc/conf.d/hostname
    hostname "$HOSTNAME"
fi

pidof agetty > /dev/null 2>&1 && exit 0

echo "** OpenRC startup stuck somewhere" > /dev/tty11
echo "** (probably the entries in /etc/local.d)" > /dev/tty11

while true; do
    openvt -c 11 -w -f -s -- agetty11
    echo "Restarting..." > /dev/tty11
    sleep 1
done
