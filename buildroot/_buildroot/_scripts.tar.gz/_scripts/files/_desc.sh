#tar xzf _scripts/files/desc.tar.gz -C dir desc/pkgname.desc@ 2> /dev/null
tar xzf desc.tar.gz -C dir desc/pkgname.desc@ 2> /dev/null
