_findtime | grep "^2017[^ ]\+/23" | while read A B C; do echo "$C" | sed -e 's%^\./%%' -e 's%/.*$%%'; done| sort -u
