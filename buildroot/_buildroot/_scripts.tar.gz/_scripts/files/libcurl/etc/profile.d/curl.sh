export CURL_CA_BUNDLE="/etc/ssl/ca-bundle.crt"
