export XDG_DATA_DIRS=/usr/local/share:/usr/share
export XDG_CONFIG_DIRS=/etc/xdg
#XDG_RUNTIME_DIR=/run/user/$(id -u)
