if [ "$(locale charmap)" = "UTF-8" ]; then
    export LESSCHARSET="utf-8"
fi
