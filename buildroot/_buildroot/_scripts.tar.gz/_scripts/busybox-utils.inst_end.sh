B_BOX_BIN=busybox-utils

rm -f $DESTROOT/sbin/init
rm -f $DESTROOT/sbin/start-stop-daemon
rm -f $DESTROOT/bin/hostname
rm -f $DESTROOT/bin/dnsdomainname

mkdir -p $DESTROOT/bin/alt-bin
mv $DESTROOT/bin/busybox $DESTROOT/bin/alt-bin/$B_BOX_BIN

find $DESTROOT/bin $DESTROOT/sbin $DESTROOT/usr/bin $DESTROOT/usr/sbin -type l | \
while read link; do
    LNK=`readlink "$link"`
    if echo "$LNK" | grep -q "/"; then
	LNK_DST=`echo "$LNK" | sed -e "s%/bin/%/bin/alt-bin/%" -e "s%/busybox%/$B_BOX_BIN%"`
    else
	LNK_DST=`echo "$LNK" | sed -e "s%.*%alt-bin/&%" -e "s%/busybox%/$B_BOX_BIN%"`
    fi
    ln -sf $LNK_DST $link
done
