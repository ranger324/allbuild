mkdir -p $DESTROOT/usr/lib/nss-static
mv $DESTROOT/usr/lib/*.a $DESTROOT/usr/lib/nss-static
mv $DESTROOT/usr/lib/nss-static/libcrmf.a $DESTROOT/usr/lib
mv $DESTROOT/usr/lib/nss-static/libjar.a $DESTROOT/usr/lib
