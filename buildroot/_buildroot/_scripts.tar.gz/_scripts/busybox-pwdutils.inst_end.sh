B_BOX_BIN=busybox-pwdutils

rm -f $DESTROOT/sbin/init
rm -f $DESTROOT/bin/login
rm -f $DESTROOT/bin/su
rm -f $DESTROOT/sbin/sulogin

mkdir -p $DESTROOT/bin/alt-bin
mv $DESTROOT/bin/busybox $DESTROOT/bin/alt-bin/$B_BOX_BIN

find $DESTROOT/bin $DESTROOT/sbin $DESTROOT/usr/bin $DESTROOT/usr/sbin -type l | \
while read link; do
    rm $link
    cp -dp $DESTROOT/bin/alt-bin/$B_BOX_BIN $link
done
