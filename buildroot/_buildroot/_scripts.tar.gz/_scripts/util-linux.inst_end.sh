rm $DESTROOT/sbin/fsck
