mkdir -p $DESTROOT/var/lib/ntp
