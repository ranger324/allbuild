BUILDROOT=output/build

[ -e $BUILDROOT/.python_version ] && PYTHON_VER=`cat $BUILDROOT/.python_version`
if [ ! -z "$PYTHON_VER" -a "$PYTHON_VER" = 3 ]; then
    mkdir -p $DESTROOT/usr/lib/python3.6/site-packages
else
    mkdir -p $DESTROOT/usr/lib/python2.7/site-packages
fi
