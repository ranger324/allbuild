
mkdir -p $DESTROOT/lib
mv -v $DESTROOT/usr/lib/libncursesw.so.6* $DESTROOT/lib
ln -sfv ../../lib/libncursesw.so.6 $DESTROOT/usr/lib/libncursesw.so

for lib in ncurses form panel menu; do
    rm -vf $DESTROOT/usr/lib/lib${lib}.so
    echo "INPUT(-l${lib}w)" > $DESTROOT/usr/lib/lib${lib}.so
#    ln -sfv lib${lib}w.a $DESTROOT/usr/lib/lib${lib}.a
done
#ln -sfv libncurses++w.a $DESTROOT/usr/lib/libncurses++.a
#rm -vf $DESTROOT/usr/lib/libcursesw.so
echo "INPUT(-lncursesw)" > $DESTROOT/usr/lib/libcursesw.so
ln -sfv libncurses.so $DESTROOT/usr/lib/libcurses.so
ln -sfv libncursesw.a $DESTROOT/usr/lib/libcursesw.a
ln -sfv libncurses.a $DESTROOT/usr/lib/libcurses.a

mkdir -p $DESTROOT/usr/include/ncurses
ln -sf ncurses $DESTROOT/usr/include/ncursesw

(cd $DESTROOT/usr/include
for i in *.h; do
    ln -s ../$i ncurses/$i
done)

#(cd $DESTROOT/usr/include;
#ls *.h | xargs -r -i ln -sf ../{} $DESTROOT/usr/include/ncurses/{})
