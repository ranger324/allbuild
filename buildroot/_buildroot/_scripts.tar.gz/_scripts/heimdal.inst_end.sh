rm $DESTROOT/usr/bin/su
find $DESTROOT/usr/share/man -name "su.1" | xargs rm
mv $DESTROOT/usr/lib/heimdal/pkgconfig $DESTROOT/usr/lib
