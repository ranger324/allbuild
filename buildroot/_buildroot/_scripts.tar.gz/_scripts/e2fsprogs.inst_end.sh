gunzip $DESTROOT/usr/share/info/libext2fs.info.gz
