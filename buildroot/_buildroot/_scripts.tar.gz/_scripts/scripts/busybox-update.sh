#[0-9a-zA-Z_-] busybox filenames "busybox" "busybox-..."
#findutils bins
cmdlist=('find' 'locate' 'xargs' 'bigram' 'code' 'frcode')
#####cmdlist=('')
ls_bbox_links() {
find $root/bin $root/sbin $root/usr/bin $root/usr/sbin -maxdepth 1 -type l 2> /dev/null | \
while read line; do
    echo -n "$line "
    readlink "$line"
done | grep "[ /]busybox-[0-9a-zA-Z_-]\+$\|[ /]busybox$" | cut -d ' ' -f 1 | \
while read line; do
    CMD=`basename "$line"`
    echo "$CMD $line"
done
}

ls_bbox_links | \
while read cmd link; do
    for pkg_cmd in ${cmdlist[@]}; do
	[ "$pkg_cmd" = "$cmd" ] && rm "$link"
    done
done
