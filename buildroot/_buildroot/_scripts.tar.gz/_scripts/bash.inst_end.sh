ln -sfv bash $DESTROOT/bin/sh
