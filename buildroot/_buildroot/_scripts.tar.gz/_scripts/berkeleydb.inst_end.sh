rm -rf $DESTROOT/usr/docs
#mv docs
