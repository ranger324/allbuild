chmod 700 $DESTROOT/var/lib/udisks2
