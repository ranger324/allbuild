#pragma once

#include <animal.hh>

class Mouse : public Animal
{
public:
    Mouse (std::string name);
};
